#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include "setting_up.h"
#include "commands.h"

/**
 * This function prints out all the commands
 * @param canvas: the board the user is drawing on
 * @return: nothing, void function
 */
void print_help(Board canvas){
    printf("Commands:\n");
    printf("Help: h\n");
    printf("Quit: q\n");
    printf("Draw line: w row_start col_start row_end col_end\n");
    printf("Resize: r num_rows num_cols\n");
    printf("Add row or column: a [r | c] pos\n");
    printf("Delete row or column: d [r | c] pos\n");
    printf("Erase: e row col\n");
    printf("Save: s file_name\n");
    printf("Load: l file_name\n");
    print_board(canvas);
}

/**
 * This function gets the slope of two points
 * @param r1: the x coordinate of first point
 * @param c1: the y coordinate of first point
 * @param r2: x coordinate of second point
 * @param c2: y coordinate of second point
 * @return: a double containing the positive or negative slope of the two points
 */
double findSlope(int r1, int c1, int r2, int c2) {
    double slope = (c2 - c1) / ((double)r2 - r1);
    return slope;
}


/**
 * This function checks if the slope / line between two points is straight / has an absolute value of 1
 * @param r1: the x coordinate of first point
 * @param c1: the y coordinate of first point
 * @param r2: x coordinate of second point
 * @param c2: y coordinate of second point
 * @return: true if slope is straight and can be drawn on board, false otherwise
 */
bool straightLine(int r1, int c1, int r2, int c2) {
    double slope = findSlope(r1, c1, r2, c2);
    if (slope == 1 || slope == -1) {
        return true;
    }
    return false;
}

/**
 * This function draws a line between the user's points
 * @param canvas: the board the user is drawing on
 * @param r1: the x coordinate of first point
 * @param c1: the y coordinate of first point
 * @param r2: x coordinate of second point
 * @param c2: y coordinate of second point
 * @return: nothing, void function
 */
void write_board(Board canvas, int r1, int c1, int r2, int c2) {

    // one cell line
    if (r1 == r2 && c1 == c2) {
        if (canvas.board[canvas.numRows - r1 - 1][c1] != '*' && canvas.board[canvas.numRows - r1 - 1][c1] != '-') {
            canvas.board[canvas.numRows - r1 - 1][c1] = '+';
        } else {
            canvas.board[canvas.numRows - r1 - 1][c1] = '-';
        }
        print_board(canvas);
        return;
    }

    // horizontal line (same row)
    if (r1 == r2) {
        if (c1 < c2) {
            for (int i = c1; i <= c2; i++) {
                if ((canvas.board[canvas.numRows-r1-1][i] != '*' && canvas.board[canvas.numRows-r1-1][i] != '-') || canvas.board[canvas.numRows-r1-1][i] == '+') {
                    canvas.board[canvas.numRows-r1-1][i] = '+';
                } else {
                    canvas.board[canvas.numRows-r1-1][i] = '-';
                }
            }
        } else {
            for (int i = c1; i >= c2; i--) {
                if ((canvas.board[canvas.numRows-r1-1][i] != '*' && canvas.board[canvas.numRows-r1-1][i] != '-') || canvas.board[canvas.numRows-r1-1][i] == '+')  {
                    canvas.board[canvas.numRows-r1-1][i] = '+';
                } else {
                    canvas.board[canvas.numRows-r1-1][i] = '-';
                }            
            }
        }
        print_board(canvas);
        return;
    }

    // vertical line (same column)
    if (c1 == c2) {
        if (r1 < r2) {
            for (int i = r1; i <= r2; i++) {
                if ((canvas.board[canvas.numRows - i - 1][c1] != '*' && canvas.board[canvas.numRows - i - 1][c1] != '|') || canvas.board[canvas.numRows - i - 1][c1] == '+') {
                    canvas.board[canvas.numRows - i - 1][c1] = '+';
                }
                else {
                    canvas.board[canvas.numRows - i - 1][c1] = '|';
                }
            }  
        } else {
            for (int i = r1; i >= r2; i--) {
                if ((canvas.board[canvas.numRows - i - 1][c1] != '*' && canvas.board[canvas.numRows - i - 1][c1] != '|') || canvas.board[canvas.numRows - i - 1][c1] == '+') {
                    canvas.board[canvas.numRows - i - 1][c1] = '+';
                }
                else {
                    canvas.board[canvas.numRows - i - 1][c1] = '|';
                }
            }
        }
        print_board(canvas);
        return;
    }

    // draw diagonals
    if (straightLine(r1, c1, r2, c2)) {
         // right diagonal, line goes like /
        if (findSlope(r1, c1, r2, c2) > 0) {
            int x = c1;
            if (r1 < r2 && c1 < c2) {
                for (int i = r1; i <= r2; i++) {
                    if ((canvas.board[canvas.numRows-i-1][x] != '*' && canvas.board[canvas.numRows-i-1][x] != '/') || canvas.board[canvas.numRows-i-1][x] == '+') {
                        canvas.board[canvas.numRows-i-1][x] = '+';
                    }
                    else {
                        canvas.board[canvas.numRows-i-1][x] = '/';
                    }
                    x++;
                }
            } else {
                for (int i = r1; i >= r2; i--) {
                    if ((canvas.board[canvas.numRows-i-1][x] != '*' && canvas.board[canvas.numRows-i-1][x] != '/') || canvas.board[canvas.numRows-i-1][x] == '+') {
                        canvas.board[canvas.numRows-i-1][x] = '+';
                    }
                    else {
                        canvas.board[canvas.numRows-i-1][x] = '/';
                    }
                    x--;
                }
            }
        } else { /* left diagonal, line goes like \ */
            int x = c1;
            if (r1 < r2) {
                for (int i = r1; i <= r2; i++) {
                    if ((canvas.board[canvas.numRows-i-1][x] != '*' && canvas.board[canvas.numRows-i-1][x] != '\\') || canvas.board[canvas.numRows-i-1][x] == '+' ) {
                        canvas.board[canvas.numRows-i-1][x] = '+';
                    }
                    else {
                        canvas.board[canvas.numRows-i-1][x] = '\\';
                    }
                    x--;
                }
            } else {
                for (int i = r1; i >= r2; i--) {
                    if ((canvas.board[canvas.numRows-i-1][x] != '*' && canvas.board[canvas.numRows-i-1][x] != '\\') || canvas.board[canvas.numRows-i-1][x] == '+' ) {
                        canvas.board[canvas.numRows-i-1][x] = '+';
                    }
                    else {
                        canvas.board[canvas.numRows-i-1][x] = '\\';
                    }
                    x++;
                }
            }
        }
        print_board(canvas);
        return;
    }
}

/**
 * This function makes a point on the board a blank space
 * @param canvas: the board the user is drawing on
 * @param row: the row of the point being erased
 * @param col: the column of the point being erased
 * @return: nothing, void function
 */
void erasePoint(Board canvas, int row, int col) {
    canvas.board[canvas.numRows - row - 1][col] = '*';
    print_board(canvas);
}

/**
 * This function adds a row to the board at the given position
 * @param canvas: the board the user is drawing on
 * @param rowPos: the # row position the user wants to add a row in
 * @return: nothing, void function
 */
void addRow(Board* canvas, int rowPos) {
    canvas->numRows = canvas->numRows + 1;
    canvas->board = (char**)realloc(canvas->board, (canvas->numRows) * sizeof(char*));
    canvas->board[canvas->numRows - 1] = (char*)malloc(canvas->numCols * sizeof(char));
    // realloc space in the new row

    int numberRows = canvas->numRows;

    // move every row below rowPos down 1
    for (int i = numberRows - 1; i > numberRows - rowPos - 1; i--) {
        for (int x = 0; x < canvas->numCols; x++) {
            canvas->board[i][x] = canvas->board[i - 1][x];
        }
    }

    for (int i = 0; i < canvas->numCols; i++) {
        canvas->board[numberRows - rowPos - 1][i] = '*';
    }

    print_board(*canvas);
}

/**
 * This function adds a column to the board at the given position
 * @param canvas: the board the user is drawing on
 * @param colPos: the # column position the user wants to add a column in
 * @return: nothing, void function
 */
void addCol(Board* canvas, int colPos) {
    canvas->numCols++;
    int numberCols = canvas->numCols;
    for (int i = 0; i < canvas->numRows; i++) {
        canvas->board[i] = (char*)realloc(canvas->board[i], numberCols * sizeof(char));
        canvas->board[i][numberCols - 1] = '*';
    }

    // move very col after colPos right 1
    for (int i = 0; i < canvas->numRows; i++) {
        for (int j = numberCols-1; j > colPos; j--) {
            canvas->board[i][j] = canvas->board[i][j-1];
        }
        canvas->board[i][colPos] = '*';
    }

    print_board(*canvas);

}

/**
 * This function deletes the row at the given position on the board and print it after
 * @param canvas: the board the user is drawing on
 * @param rowPos: the # row position the user wants to delete
 * @return: nothing, void function
 */
void deleteRow(Board* canvas, int rowPos) {
    canvas->numRows--;
    int numberRows = canvas->numRows;
    // move every row below rowPos up 1
    for (int i = numberRows - rowPos; i < numberRows; i++) {
        for (int x = 0; x < canvas->numCols; x++) {
            canvas->board[i][x] = canvas->board[i+1][x];
        }
    }

    // realloc space last
    // free(canvas->board[numberRows]); // idk why but it crashes
    canvas->board = (char**)realloc(canvas->board, numberRows * sizeof(char*));
    print_board(*canvas);
}

/**
 * This function deletes the row at the given position on the board without printing the board after
 * @param canvas: the board the user is drawing on
 * @param rowPos: the # row position the user wants to delete
 * @return: nothing, void function
 */
void deleteRow_noPrinting(Board* canvas, int rowPos) {
    canvas->numRows--;
    int numberRows = canvas->numRows;
    // move every row below rowPos up 1
    for (int i = numberRows - rowPos; i < numberRows; i++) {
        for (int x = 0; x < canvas->numCols; x++) {
            canvas->board[i][x] = canvas->board[i+1][x];
        }
    }

    // realloc space last
    // free(canvas->board[numberRows]); // idk why but it crashes
    canvas->board = (char**)realloc(canvas->board, numberRows * sizeof(char*));
}

/**
 * This function deletes the column at the given position on the board and prints the board after
 * @param canvas: the board the user is drawing on
 * @param colPos: the # column position the user wants to delete
 * @return: nothing, void function
 */
void deleteCol(Board* canvas, int colPos) {
    canvas->numCols--;
    int numberCols = canvas->numCols;

    for (int i = 0; i < canvas->numRows; i++) {
        for (int j = colPos; j < numberCols; j++) {
            canvas->board[i][j] = canvas->board[i][j+1];
        }
    }

    // realloc space
    for (int i = 0; i < canvas->numRows; i++) {
        canvas->board[i] = (char*)realloc(canvas->board[i], numberCols * sizeof(char));
    }
    print_board(*canvas);
}

/**
 * This function deletes the column at the given position on the board without printing the board after
 * @param canvas: the board the user is drawing on
 * @param colPos: the # column position the user wants to delete
 * @return: nothing, void function
 */
void deleteCol_noPrinting(Board* canvas, int colPos) {
    canvas->numCols--;
    int numberCols = canvas->numCols;

    for (int i = 0; i < canvas->numRows; i++) {
        for (int j = colPos; j < numberCols; j++) {
            canvas->board[i][j] = canvas->board[i][j+1];
        }
    }

    // realloc space
    for (int i = 0; i < canvas->numRows; i++) {
        canvas->board[i] = (char*)realloc(canvas->board[i], numberCols * sizeof(char));
    }
}

/**
 * This function resizes the canvas to the given # of rows and columns
 * @param canvas: the board that is being resized
 * @param rows: the # of rows the user wants the board to be
 * @param cols: the # of columns the user wants the board to be
 * @return: nothing, void function
 */
void resizeBoard(Board* canvas, int rows, int cols) {
    int rowChange = rows - canvas->numRows; // how many rows we need to add or subtract
    int colChange = cols - canvas->numCols;

    // if we need to increase the # of rows
    if (rowChange > 0) {
        canvas->numRows = canvas->numRows + rowChange;
        canvas->board = (char**)realloc(canvas->board, (canvas->numRows) * sizeof(char*));
        // make space for new # of rows
        for (int i = 0; i < rowChange; i++) {
            canvas->board[canvas->numRows - 1 - i] = (char*)malloc(canvas->numCols * sizeof(char));
            for (int x = 0; x < canvas->numCols; x++) {
                canvas->board[canvas->numRows - 1 - i][x] = '*';
            }
        } 

        // move every row down to bottom
        int numberRows = canvas->numRows;
        for (int i = numberRows - 1; i >= rowChange; i--) {
            for (int x = 0; x < canvas->numCols; x++) {
                canvas->board[i][x] = canvas->board[i - rowChange][x];
            }
        }
        // make the new spaces default again
        for (int i = 0; i < rowChange; i++) {
            for (int j = 0; j < canvas->numCols; j++) {
                canvas->board[i][j] = '*';
            }   
        }
    } else if (rowChange < 0) { // dec # of rows
        for (int i = 0; i < abs(rowChange); i++) {
            deleteRow_noPrinting(canvas, canvas->numRows-1);
        }
    }

    if (colChange > 0) { // if we need to increase the # of cols
        canvas->numCols = canvas->numCols + colChange;
        for (int i = 0; i < canvas->numRows; i++) {
            canvas->board[i] = (char*)realloc(canvas->board[i], (canvas->numCols) * sizeof(char));
            for (int x = 0; x < colChange; x++) {
                canvas->board[i][canvas->numCols - 1 - x] = '*';
            }
        }
    } else if (colChange < 0) { // dec # of rows
        for (int i = 0; i < abs(colChange); i++) {
            deleteCol_noPrinting(canvas, canvas->numCols - 1);
        }
    }
    print_board(*canvas);

}

/**
 * This function saves the board to a text file that contains the dimensions and contents of the board
 * @param canvas: the board the user is saving
 * @param destName: the name of the file the user wants to save the canvas to
 * @return: nothing, void function
 */
void save_canvas(Board* canvas, char* destName) {
    FILE* file_name = fopen(destName, "w");
 
    if(file_name == NULL) {
        printf("failed \n");
        return;
    }
    fprintf(file_name, "%d %d", canvas->numRows, canvas->numCols);
    for (int i = 0; i < canvas->numRows; i++) {
        for (int j = 0; j < canvas->numCols; j++) {
            fprintf(file_name, "%c", canvas->board[i][j]);
        }
        fprintf(file_name, "%c", ' ');
    }
    print_board(*canvas);
    fclose(file_name);
}

// taken from class folder
/**
 * This function adds a character to a string
 * @param val: the character the user is adding
 * @param str: the name of the string that is being appened to
 * @param size: the size of the string
 * @return: a string with the appended values
 */
char* append(char val, char* str, int* size){
	(*size)++;
	str = (char*)realloc(str, *size * sizeof(char));
	str[*size - 1] = val;
	return str;
}

/**
 * This function reads a string of any length
 * @return: a string with the read characters and values
 */
char* read_any_len_str() {
	char cur_char;
	char* str = NULL;
	int cur_size = 0;

    //####hello
	//skip leading whitespace
	do{
		scanf("%c", &cur_char);
	}while(isspace(cur_char));

	do{
		str = append(cur_char, str, &cur_size);
		scanf("%c", &cur_char);
	}while(!isspace(cur_char));

	//add the null character
	str = append('\0', str, &cur_size);

	return str;
}

/**
 * This function opens a text file of a previously saved board
 * @param canvas: the board that will be drawn on / replaced by the file
 * @param source: the name of the file the user is opening
 * @return: nothing, void function
 */
void openCanvas(Board* canvas, char* source){
    FILE* src = fopen(source, "r");

    int numberRows;
    int numberCols;
    fscanf(src, " %d %d", &numberRows, &numberCols);

    canvas->numRows = numberRows;
    canvas->numCols = numberCols;

    // make space for the board
    canvas->board = (char**)calloc(canvas->numRows, sizeof(char*));
    for (int i = 0; i < canvas->numRows; i++) {
        canvas->board[i] = (char*)calloc(canvas->numCols, sizeof(char));
    }


    char c;
    for (int i = 0; i < canvas->numRows; i++) {
        for (int x = 0; x < canvas->numCols; x++) {
            fscanf(src, " %c", &c);
            canvas->board[i][x] = c;
        }
    }

    print_board(*canvas);
    fclose(src);

}