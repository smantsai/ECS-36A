#ifndef COMMANDS_H
    #define COMMANDS_H

    void print_help(Board canvas);
    double findSlope(int r1, int c1, int r2, int c2);
    bool straightLine(int r1, int c1, int r2, int c2);
    void write_board(Board canvas, int r1, int c1, int r2, int c2);
    void erasePoint(Board canvas, int row, int col);
    void addRow(Board* canvas, int rowPos);
    void addCol(Board* canvas, int colPos);
    void deleteRow(Board* canvas, int rowPos);
    void deleteRow_noPrinting(Board* canvas, int rowPos);
    void deleteCol(Board* canvas, int colPos);
    void deleteCol_noPrinting(Board* canvas, int colPos);
    void resizeBoard(Board* canvas, int rows, int cols);
    void save_canvas(Board* canvas, char* destName);
    char* append(char val, char* str, int* size);
    char* read_any_len_str();
    void openCanvas(Board* canvas, char* source);

#endif