#ifndef SETTING_UP_H
    #define SETTING_UP_H

    typedef struct Board_struct {
        int numRows;
        int numCols;

        char** board;
    } Board;

    Board create_board(int argc, char** argv);
    void print_board(Board canvas);


    
#endif