/* This program allows the user to draw on a board in the terminal*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

#include "setting_up.h"
#include "commands.h"

/**
 * This function gets commands from the user until q is entered
 * @param canvas: the board that the user is drawing on
 * @return: nothing, void function
 */
void getCommands(Board canvas){
    char command;
    printf("Enter your command: ");
    scanf(" %c", &command);
    while (command != 'q') {
        if (command == 'h') {
            print_help(canvas);
        } else if (command == 'w') {
            int r1, r2, c1, c2;
            scanf(" %d %d %d %d", &r1, &c1, &r2, &c2);
            write_board(canvas, r1, c1, r2, c2);
        } else if (command == 'e') {
            int r, c;
            scanf(" %d %d", &r, &c);
            erasePoint(canvas, r, c);
        } else if (command == 'r') {
            int r, c;
            scanf(" %d %d", &r, &c);
            resizeBoard(&canvas, r, c);
        } else if (command == 'a') {
            char rowOrCol;
            int pos;
            scanf(" %c %d", &rowOrCol, &pos);
            if (rowOrCol == 'r') {
                addRow(&canvas, pos);
            } else {
                addCol(&canvas, pos);
            }
        } else if (command == 'd') { // reverse of adding
            char rowOrCol;
            int pos;
            scanf(" %c %d", &rowOrCol, &pos);
            if (rowOrCol == 'r') {
                deleteRow(&canvas, pos);
            } else {
                deleteCol(&canvas, pos);
            }
        } else if (command == 's') {
            char* fileName = read_any_len_str();
            save_canvas(&canvas, fileName);
        } else if (command == 'l') {
            char* fileName = read_any_len_str();
            openCanvas(&canvas, fileName);
        } else {
            printf("Unrecognized command. Type h for help.\n");
        }
        printf("Enter your command: ");
        scanf(" %c", &command);
    }

    // get to this point when user types in q, free up the space
    for (int i = 0; i < canvas.numRows; i++) {
        free(canvas.board[i]);
    }
    free(canvas.board);
}

int main(int argc, char** argv) {
    Board canvas = create_board(argc, argv);

    // get user's commands
    print_board(canvas);
    getCommands(canvas);


    return 0;
}