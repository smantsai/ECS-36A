#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include "setting_up.h"

/**
 * This function sets up the board's dimensions to a user's given size or the default 10x10 size.
 * @param argc: the # of inputs the user puts in on the command line
 * @param argv: the inputs that the user gives, should contain the dimensions
 * @return: a Board with the user's valid dimensions
 */
Board create_board(int argc, char** argv) {
    Board canvas;

    // default size
    canvas.numRows = 10;
    canvas.numCols = 10;
    
    // initalize to size indicated
    if (argc == 3) {
        int rows = atoi(argv[1]);
        int cols = atoi(argv[2]);
        
        if (rows >= 1 && cols >= 1) { // will overwrite the default size
            canvas.numRows = rows;
            canvas.numCols = cols;
        } else if (rows < 1) {
            printf("The number of rows is less than 1.\n");
            printf("Making default board of 10 X 10.\n");
        } else if (cols < 1) {
            printf("The number of columns is less than 1.\n");
            printf("Making default board of 10 X 10.\n");
        }
    } else if (argc == 2){
        printf("Wrong number of command line arguments entered.\n");
        printf("Usage: ./paint.out [num_rows num_cols]\n");
        printf("Making default board of 10 X 10.\n");

    }

    // making space for the board
    canvas.board = (char**)calloc(canvas.numRows, sizeof(char*));
    for (int i = 0; i < canvas.numRows; i++) {
        canvas.board[i] = (char*)calloc(canvas.numCols, sizeof(char));
    }

    // initialize everything to a blank character (*)
    for (int i = 0; i < canvas.numRows; i++) {
        for (int j = 0; j < canvas.numCols; j++) {
            canvas.board[i][j] = '*';
        }
    }

    return canvas;

}

/**
 * This function prints out the canvas of the board
 * @param canvas: the board the user drew on and is printing out
 * @return: nothing, void function
 */
void print_board(Board canvas){
    int k = 0;
    for (int i = canvas.numRows - 1; i >= 0; i--) {
        printf("%d ", i);
        for (int j = 0; j < canvas.numCols; j++) {
            printf("%c ", canvas.board[k][j]);
        }
        k++;
        printf("\n");
    }

    printf("  ");
    for (int x = 0; x < canvas.numCols; x++) {
        printf("%d ", x);
    }
    printf("\n");
}